# Treasure Hunter (Android, Kotlin, fully offline)

Procedurally generated maze adventure. No external assets or libraries: graphics are drawn with
Canvas, sounds and music are synthesized at runtime, progress is saved in SharedPreferences.

## Build the APK

### Option A: Android Studio (easiest)
1. Install Android Studio (Koala or newer; it bundles JDK 17).
2. File > Open > select this `TreasureHunter` folder. Let Gradle sync finish (first sync downloads Gradle 8.7 and the Android SDK 34 platform).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK: `app/build/outputs/apk/debug/app-debug.apk`. Copy it to the phone and open it
   (allow "Install unknown apps"), or press Run with a phone connected via USB debugging.

### Option B: Command line
Requirements: JDK 17, Android SDK (platform 34, build-tools 34.0.0), Gradle 8.7+.
```
echo "sdk.dir=/path/to/Android/Sdk" > local.properties
gradle wrapper --gradle-version 8.7     # one time, creates ./gradlew
./gradlew assembleDebug                 # -> app/build/outputs/apk/debug/app-debug.apk
./gradlew assembleRelease               # -> app/build/outputs/apk/release/app-release.apk (debug-signed, installable)
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

### Option C: GitHub Actions (no local setup)
Push this folder to a GitHub repo. `.github/workflows/build.yml` builds the APK; download it from the run's Artifacts.

## How to play
Touch and drag anywhere to steer (floating joystick). Reach the glowing portal before time runs out.
- Coins / gems: score and gold. Clocks: +8 seconds.
- Hidden chests: invisible until you get close; look for sparkles in dead ends.
- Spikes: they flash, then pop up. Slimes patrol corridors. Both cost a heart.
- Cracked walls are secret passages: walk through them for shortcuts and a bonus.
- Cyan arrow points toward the exit.
- Gold buys skins and upgrades (speed, hearts, magnet, gold bonus) in the Shop.
- Back button pauses.

## Layout
- `GameView.kt`: gameplay, rendering, menus, shop, input
- `Maze.kt`: generator (backtracker + loops + secret walls), BFS
- `SoundFx.kt`: synthesized effects and music loop
- `Save.kt`: gold, skins, upgrades, high scores, best level, sound setting
