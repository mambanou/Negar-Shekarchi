package com.treasurehunter.game

import kotlin.random.Random

/**
 * Tile-based maze. Cells live on odd tile coordinates, passages on the tiles between.
 * Recursive-backtracker + extra loops + secret walls (walkable, cracked-looking).
 */
class Maze(val cols: Int, val rows: Int, secrets: Int, rnd: Random) {
    val w = cols * 2 + 1
    val h = rows * 2 + 1
    val wall = Array(h) { BooleanArray(w) { true } }
    val secret = Array(h) { BooleanArray(w) }
    val revealed = Array(h) { BooleanArray(w) }

    init {
        val vis = BooleanArray(cols * rows)
        val stack = ArrayList<Int>()
        vis[0] = true; wall[1][1] = false; stack.add(0)
        val dirs = arrayOf(intArrayOf(1, 0), intArrayOf(-1, 0), intArrayOf(0, 1), intArrayOf(0, -1))
        while (stack.isNotEmpty()) {
            val cur = stack[stack.size - 1]
            val cx = cur % cols; val cy = cur / cols
            val opts = dirs.filter {
                val nx = cx + it[0]; val ny = cy + it[1]
                nx in 0 until cols && ny in 0 until rows && !vis[ny * cols + nx]
            }
            if (opts.isEmpty()) { stack.removeAt(stack.size - 1); continue }
            val d = opts[rnd.nextInt(opts.size)]
            val nx = cx + d[0]; val ny = cy + d[1]
            wall[cy * 2 + 1 + d[1]][cx * 2 + 1 + d[0]] = false
            wall[ny * 2 + 1][nx * 2 + 1] = false
            vis[ny * cols + nx] = true
            stack.add(ny * cols + nx)
        }
        // Wall segments separating two open cells: candidates for loops / secrets.
        val cand = ArrayList<IntArray>()
        for (y in 1 until h - 1) for (x in 1 until w - 1) if (wall[y][x]) {
            val horiz = !wall[y][x - 1] && !wall[y][x + 1]
            val vert = !wall[y - 1][x] && !wall[y + 1][x]
            if (horiz != vert) cand.add(intArrayOf(x, y))
        }
        cand.shuffle(rnd)
        val loops = minOf((cand.size * 0.06f).toInt() + 1, cand.size)
        for (i in 0 until loops) wall[cand[i][1]][cand[i][0]] = false
        var made = 0
        var i = loops
        while (made < secrets && i < cand.size) {
            val c = cand[i++]
            secret[c[1]][c[0]] = true
            made++
        }
    }

    /** Solid for the player (secret walls can be walked through). */
    fun solid(x: Int, y: Int) = x < 0 || y < 0 || x >= w || y >= h || (wall[y][x] && !secret[y][x])

    /** Blocked for enemies / pathfinding (secret walls count as walls). */
    fun blocked(x: Int, y: Int) = x < 0 || y < 0 || x >= w || y >= h || wall[y][x]

    fun reveal(x: Int, y: Int) {
        secret[y][x] = false; wall[y][x] = false; revealed[y][x] = true
    }

    fun bfs(sx: Int, sy: Int): Array<IntArray> {
        val d = Array(h) { IntArray(w) { -1 } }
        val q = IntArray(w * h)
        var head = 0; var tail = 0
        d[sy][sx] = 0; q[tail++] = sy * w + sx
        while (head < tail) {
            val c = q[head++]; val x = c % w; val y = c / w
            for ((dx, dy) in listOf(1 to 0, -1 to 0, 0 to 1, 0 to -1)) {
                val nx = x + dx; val ny = y + dy
                if (!blocked(nx, ny) && d[ny][nx] < 0) { d[ny][nx] = d[y][x] + 1; q[tail++] = ny * w + nx }
            }
        }
        return d
    }
}
