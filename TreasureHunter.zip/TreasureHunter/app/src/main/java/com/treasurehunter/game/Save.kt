package com.treasurehunter.game

import android.content.Context

/** Local, offline persistence (SharedPreferences). */
class Save(ctx: Context) {
    private val p = ctx.getSharedPreferences("treasure_save", Context.MODE_PRIVATE)

    var gold: Int
        get() = p.getInt("gold", 0)
        set(v) { p.edit().putInt("gold", v).apply() }
    var skin: Int
        get() = p.getInt("skin", 0)
        set(v) { p.edit().putInt("skin", v).apply() }
    var owned: Int
        get() = p.getInt("owned", 1)
        set(v) { p.edit().putInt("owned", v).apply() }
    var sound: Boolean
        get() = p.getBoolean("sound", true)
        set(v) { p.edit().putBoolean("sound", v).apply() }
    var bestLevel: Int
        get() = p.getInt("bestLevel", 1)
        set(v) { p.edit().putInt("bestLevel", v).apply() }

    fun upgrade(i: Int): Int = p.getInt("up$i", 0)
    fun setUpgrade(i: Int, v: Int) { p.edit().putInt("up$i", v).apply() }

    fun scores(): List<Int> =
        (p.getString("scores", "") ?: "").split(",").mapNotNull { it.toIntOrNull() }

    /** Stores a score in the top 5. Returns true if it is the new #1. */
    fun addScore(s: Int): Boolean {
        val old = scores()
        val all = (old + s).sortedDescending().take(5)
        p.edit().putString("scores", all.joinToString(",")).apply()
        return s > 0 && (old.isEmpty() || s > old.first())
    }
}
