package com.treasurehunter.game

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/** All sound effects and music are synthesized at runtime: no audio assets needed. */
class SoundFx {
    var enabled = true
    private val sr = 22050
    private val tracks = HashMap<String, AudioTrack>()
    private var music: AudioTrack? = null

    init {
        try {
            add("coin", cat(synth(1175f, 1175f, .05f), synth(1568f, 1568f, .14f, decay = 8f)))
            add("gem", cat(synth(880f, 880f, .06f), synth(1108f, 1108f, .06f), synth(1318f, 1318f, .06f), synth(1760f, 1760f, .16f, decay = 6f)))
            add("chest", cat(synth(523f, 523f, .08f), synth(659f, 659f, .08f), synth(784f, 784f, .08f), synth(1047f, 1047f, .08f), synth(1318f, 1318f, .3f, decay = 4f)))
            add("hit", synth(320f, 70f, .35f, vol = .8f, noise = true))
            add("win", cat(synth(523f, 523f, .12f), synth(659f, 659f, .12f), synth(784f, 784f, .12f), synth(1047f, 1047f, .4f, decay = 3f)))
            add("lose", synth(420f, 90f, .7f, vol = .6f))
            add("click", synth(760f, 760f, .05f, decay = 10f))
            add("secret", cat(synth(500f, 1300f, .25f, vol = .5f), synth(1568f, 1568f, .2f, decay = 7f)))
            add("clock", cat(synth(1000f, 1000f, .06f), synth(1300f, 1300f, .1f, decay = 8f)))
            add("bad", synth(200f, 150f, .15f, vol = .5f))
            val mel = floatArrayOf(523f, 659f, 784f, 659f, 587f, 698f, 880f, 698f, 523f, 659f, 784f, 1047f, 880f, 784f, 659f, 587f)
            val parts = ArrayList<ShortArray>()
            for ((i, f) in mel.withIndex()) {
                val a = synth(f, f, .24f, vol = .3f, decay = 5f)
                val b = synth(if (i % 4 == 0) f / 4 else f / 2, if (i % 4 == 0) f / 4 else f / 2, .24f, vol = .25f, decay = 3f)
                parts.add(ShortArray(a.size) { k -> (a[k] + b[k]).coerceIn(-32000, 32000).toShort() })
            }
            val data = cat(*parts.toTypedArray())
            music = build(data).also { it.setLoopPoints(0, data.size, -1); it.setVolume(0.35f) }
        } catch (_: Throwable) { }
    }

    fun play(name: String) {
        if (!enabled) return
        try { tracks[name]?.let { it.stop(); it.reloadStaticData(); it.play() } } catch (_: Throwable) { }
    }

    fun music(on: Boolean) {
        try { if (on && enabled) music?.play() else music?.pause() } catch (_: Throwable) { }
    }

    fun release() {
        try { tracks.values.forEach { it.release() }; music?.release() } catch (_: Throwable) { }
    }

    private fun add(n: String, d: ShortArray) { tracks[n] = build(d) }

    private fun build(d: ShortArray): AudioTrack {
        val t = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(d.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC).build()
        t.write(d, 0, d.size)
        return t
    }

    private fun cat(vararg a: ShortArray): ShortArray {
        val out = ShortArray(a.sumOf { it.size }); var i = 0
        for (s in a) { s.copyInto(out, i); i += s.size }
        return out
    }

    private fun synth(f0: Float, f1: Float, dur: Float, vol: Float = .45f, decay: Float = 0f, noise: Boolean = false): ShortArray {
        val n = (dur * sr).toInt()
        val out = ShortArray(n)
        var phase = 0.0
        for (i in 0 until n) {
            val t = i / n.toFloat()
            phase += 2 * PI * (f0 + (f1 - f0) * t) / sr
            var s = sin(phase)
            if (noise) s = s * 0.4 + (Random.nextFloat() * 2 - 1) * 0.6
            val env = min(1f, min(i / 150f, (n - i) / 300f)) * exp(-decay * t)
            out[i] = (s * env * vol * 32767).toInt().toShort()
        }
        return out
    }
}
