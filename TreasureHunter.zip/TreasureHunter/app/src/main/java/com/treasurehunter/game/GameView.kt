package com.treasurehunter.game

import android.content.Context
import android.graphics.*
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import kotlin.math.*
import kotlin.random.Random

enum class St { MENU, SHOP, SCORES, PLAYING, PAUSED, CLEAR, OVER }

const val T = 80f          // tile size in world units
const val PR = 24f         // player radius
const val BASE_SPEED = 250f

fun K(v: Long) = v.toInt()
fun withA(c: Int, a: Int) = (a.coerceIn(0, 255) shl 24) or (c and 0xFFFFFF)
fun shade(c: Int, f: Float) = Color.rgb((Color.red(c) * f).toInt(), (Color.green(c) * f).toInt(), (Color.blue(c) * f).toInt())

class Btn(val r: RectF, val label: String, val color: Int, val hidden: Boolean, val act: () -> Unit)
class Item(var x: Float, var y: Float, val type: Int, val value: Int) { var alive = true } // 0 coin 1 gem 2 chest 3 clock
class Trap(val tx: Int, val ty: Int, val phase: Float)
class Enemy(var x: Float, var y: Float, var tx: Int, var ty: Int, val spd: Float, val kind: Int) { var ptx = -1; var pty = -1 }
class Particle(var x: Float, var y: Float, var vx: Float, var vy: Float, var life: Float, val color: Int, val size: Float)
class Pop(val x: Float, var y: Float, val text: String, val color: Int, var life: Float)
class Skin(val name: String, val body: Int, val hat: Int, val price: Int)
class Theme(val bg: Int, val wallTop: Int, val wallFace: Int, val floorA: Int, val floorB: Int)

val SKINS = listOf(
    Skin("Explorer", K(0xFFFFB347), K(0xFF8D6E63), 0),
    Skin("Pirate", K(0xFFE57373), K(0xFF212121), 150),
    Skin("Ninja", K(0xFF607D8B), K(0xFFB71C1C), 300),
    Skin("Frosty", K(0xFF81D4FA), K(0xFF1565C0), 450),
    Skin("Jungle", K(0xFF81C784), K(0xFF33691E), 600),
    Skin("Royal", K(0xFFBA68C8), K(0xFFFFD54F), 900)
)
val THEMES = listOf(
    Theme(K(0xFF1E1240), K(0xFF7E57C2), K(0xFF4A3480), K(0xFF2D2560), K(0xFF352C70)),
    Theme(K(0xFF12301A), K(0xFF43A047), K(0xFF1B5E20), K(0xFF3B5A33), K(0xFF42643A)),
    Theme(K(0xFF5D4037), K(0xFFE6A756), K(0xFFB8742A), K(0xFFF2DDA8), K(0xFFEAD093)),
    Theme(K(0xFF0D2A4A), K(0xFF90CAF9), K(0xFF4F8FCB), K(0xFFDDEFFC), K(0xFFCDE6F8)),
    Theme(K(0xFF2A0F0F), K(0xFF8D4B3A), K(0xFF4E2218), K(0xFF3A1B1B), K(0xFF442121))
)
val UP_NAMES = arrayOf("Swift Boots", "Extra Heart", "Gold Magnet", "Lucky Charm")
val UP_DESC = arrayOf("+8% move speed", "+1 max life", "Pulls loot closer", "+15% gold earned")
val UP_MAX = intArrayOf(5, 3, 5, 5)
val UP_BASE = intArrayOf(80, 120, 80, 100)

class GameView(ctx: Context, private val save: Save, private val snd: SoundFx) : View(ctx) {
    var st = St.MENU
    private var W = 0f; private var H = 0f
    private var u = 1f; private var ox = 0f; private var oy = 0f
    private var topInset = 0f
    private val buttons = ArrayList<Btn>()
    private var pressed: Btn? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD); textAlign = Paint.Align.CENTER
    }
    private val path = Path()
    private val rf = RectF()
    private lateinit var cv: Canvas
    private var bgShader: Shader? = null
    private var vigShader: Shader? = null
    private var lastNs = 0L
    private var time = 0f
    private val rnd = Random(System.nanoTime())

    // run state
    private var level = 1; private var score = 0
    private var hearts = 3; private var maxHearts = 3
    private var timeLeft = 0f; private var banner = 0f
    private var runGold = 0; private var runCoins = 0; private var runGems = 0; private var runChests = 0
    private var levelBonus = 0; private var timeBonus = 0
    private var newHigh = false; private var overMsg = ""
    private lateinit var maze: Maze
    private var px = 0f; private var py = 0f
    private var faceX = 0f; private var faceY = 1f; private var moving = false
    private var invuln = 0f; private var shake = 0f
    private var exitTx = 1; private var exitTy = 1
    private val items = ArrayList<Item>()
    private val traps = ArrayList<Trap>()
    private val enemies = ArrayList<Enemy>()
    private val parts = ArrayList<Particle>()
    private val pops = ArrayList<Pop>()
    private var joyId = -1; private var jox = 0f; private var joy = 0f; private var jx = 0f; private var jy = 0f
    private var msg = ""; private var msgT = 0f

    // ------------------------------------------------------------ layout / buttons
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        W = w.toFloat(); H = h.toFloat()
        u = min(W / 360f, H / 780f)
        ox = (W - 360f * u) / 2f
        oy = max(0f, (H - 780f * u) / 2f)
        bgShader = LinearGradient(0f, 0f, 0f, H, K(0xFF1B1146), K(0xFF5B2C8F), Shader.TileMode.CLAMP)
        vigShader = RadialGradient(W / 2, H / 2, max(W, H) * 0.75f, intArrayOf(0, 0, K(0xB0000000)),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        buildButtons()
    }

    @Suppress("DEPRECATION")
    override fun onApplyWindowInsets(i: WindowInsets): WindowInsets {
        topInset = i.systemWindowInsetTop.toFloat()
        if (W > 0f) buildButtons()
        return super.onApplyWindowInsets(i)
    }

    private fun rect(x: Float, y: Float, w: Float, h: Float) = RectF(ox + x * u, oy + y * u, ox + (x + w) * u, oy + (y + h) * u)
    private fun add(r: RectF, label: String, color: Int, hidden: Boolean = false, act: () -> Unit) { buttons.add(Btn(r, label, color, hidden, act)) }
    private fun go(s: St) { st = s; pressed = null; joyId = -1; buildButtons() }

    private fun buildButtons() {
        buttons.clear()
        when (st) {
            St.MENU -> {
                add(rect(60f, 380f, 240f, 64f), "PLAY", K(0xFF43A047)) { startRun() }
                add(rect(60f, 458f, 240f, 64f), "SHOP", K(0xFFFB8C00)) { go(St.SHOP) }
                add(rect(60f, 536f, 240f, 64f), "HIGH SCORES", K(0xFF1E88E5)) { go(St.SCORES) }
                add(rect(60f, 614f, 240f, 64f), if (save.sound) "SOUND: ON" else "SOUND: OFF", K(0xFF8E24AA)) {
                    save.sound = !save.sound; snd.enabled = save.sound; snd.music(save.sound); buildButtons()
                }
            }
            St.SHOP -> {
                for (i in SKINS.indices) add(skinRect(i), "", 0, true) { skinTap(i) }
                for (i in 0..3) add(upRect(i), "", 0, true) { upTap(i) }
                add(rect(110f, 716f, 140f, 48f), "BACK", K(0xFF546E7A)) { go(St.MENU) }
            }
            St.SCORES -> add(rect(110f, 690f, 140f, 52f), "BACK", K(0xFF546E7A)) { go(St.MENU) }
            St.PLAYING -> add(RectF(W - 52f * u, topInset + 6f * u, W - 8f * u, topInset + 50f * u), "", 0, true) { pauseGame() }
            St.PAUSED -> {
                add(rect(60f, 330f, 240f, 60f), "RESUME", K(0xFF43A047)) { st = St.PLAYING; joyId = -1; buildButtons() }
                add(rect(60f, 404f, 240f, 60f), "RESTART", K(0xFFFB8C00)) { startRun() }
                add(rect(60f, 478f, 240f, 60f), "MENU", K(0xFF546E7A)) { go(St.MENU) }
            }
            St.CLEAR -> add(rect(60f, 500f, 240f, 64f), "NEXT LEVEL", K(0xFF43A047)) { level++; hearts = min(maxHearts, hearts + 1); startLevel() }
            St.OVER -> {
                add(rect(60f, 450f, 240f, 60f), "TRY AGAIN", K(0xFF43A047)) { startRun() }
                add(rect(60f, 522f, 240f, 60f), "SHOP", K(0xFFFB8C00)) { go(St.SHOP) }
                add(rect(60f, 594f, 240f, 60f), "MENU", K(0xFF546E7A)) { go(St.MENU) }
            }
        }
    }

    private fun skinRect(i: Int) = rect(12f + (i % 3) * 116f, 140f + (i / 3) * 128f, 104f, 120f)
    private fun upRect(i: Int) = rect(16f, 432f + i * 68f, 328f, 60f)

    private fun skinTap(i: Int) {
        val s = SKINS[i]
        if (save.owned and (1 shl i) != 0) { save.skin = i; snd.play("click") }
        else if (save.gold >= s.price) {
            save.gold -= s.price; save.owned = save.owned or (1 shl i); save.skin = i
            snd.play("chest"); flash("${s.name} unlocked!")
        } else { snd.play("bad"); flash("Not enough gold") }
    }

    private fun upTap(i: Int) {
        val lvl = save.upgrade(i)
        if (lvl >= UP_MAX[i]) return
        val cost = UP_BASE[i] * (lvl + 1)
        if (save.gold >= cost) {
            save.gold -= cost; save.setUpgrade(i, lvl + 1); snd.play("gem"); flash("${UP_NAMES[i]} upgraded!")
        } else { snd.play("bad"); flash("Not enough gold") }
    }

    private fun flash(s: String) { msg = s; msgT = 1.6f }

    // ------------------------------------------------------------ game flow
    fun pauseGame() { if (st == St.PLAYING) { st = St.PAUSED; joyId = -1; buildButtons() } }

    fun onBack(): Boolean {
        when (st) {
            St.PLAYING -> pauseGame()
            St.PAUSED -> { st = St.PLAYING; buildButtons() }
            St.SHOP, St.SCORES, St.OVER -> go(St.MENU)
            St.CLEAR -> {}
            St.MENU -> return false
        }
        return true
    }

    private fun startRun() {
        level = 1; score = 0; runGold = 0; runCoins = 0; runGems = 0; runChests = 0
        maxHearts = 3 + save.upgrade(1); hearts = maxHearts
        startLevel()
    }

    private fun startLevel() {
        val cols = min(7 + level, 16); val rows = min(9 + level, 22)
        maze = Maze(cols, rows, min(1 + level / 2, 6), rnd)
        items.clear(); traps.clear(); enemies.clear(); parts.clear(); pops.clear()
        px = 1.5f * T; py = 1.5f * T; faceX = 0f; faceY = 1f
        val dist = maze.bfs(1, 1)
        var best = 0
        for (y in 0 until maze.h) for (x in 0 until maze.w) if (dist[y][x] > best) { best = dist[y][x]; exitTx = x; exitTy = y }
        val floors = ArrayList<IntArray>()
        for (y in 0 until maze.h) for (x in 0 until maze.w)
            if (!maze.wall[y][x] && dist[y][x] > 0 && !(x == exitTx && y == exitTy)) floors.add(intArrayOf(x, y))
        floors.shuffle(rnd)
        val used = HashSet<Int>()
        fun key(t: IntArray) = t[1] * maze.w + t[0]
        fun open(x: Int, y: Int) = listOf(1 to 0, -1 to 0, 0 to 1, 0 to -1).count { !maze.blocked(x + it.first, y + it.second) }
        fun spawn(type: Int, value: Int, pool: List<IntArray>) {
            val t = pool.firstOrNull { key(it) !in used } ?: floors.firstOrNull { key(it) !in used } ?: return
            used.add(key(t)); items.add(Item((t[0] + .5f) * T, (t[1] + .5f) * T, type, value))
        }
        val dead = floors.filter { open(it[0], it[1]) == 1 && dist[it[1]][it[0]] > 6 }
        repeat(min(1 + level / 3, 4)) { spawn(2, 300, dead) }
        repeat(cols * rows / 12 + 1) { spawn(1, listOf(50, 50, 100, 100, 200)[rnd.nextInt(5)], floors) }
        repeat(1 + min(level / 4, 2)) { spawn(3, 0, floors) }
        repeat(cols * rows * 35 / 100) { spawn(0, 10, floors) }
        val far = floors.filter { dist[it[1]][it[0]] >= 5 }.shuffled(rnd)
        for (t in far.take(min(3 + level * 2, 45))) traps.add(Trap(t[0], t[1], rnd.nextFloat() * 2.4f))
        val spots = floors.filter { dist[it[1]][it[0]] >= 8 }.shuffled(rnd)
        for (t in spots.take(min(level / 2, 8))) {
            enemies.add(Enemy((t[0] + .5f) * T, (t[1] + .5f) * T, t[0], t[1], min(55f + level * 7f, 135f), rnd.nextInt(3)))
        }
        val speed = BASE_SPEED
        timeLeft = max(best * T / speed * 2.0f + 30f - min(level, 15) * 1.2f, best * T / speed * 1.5f + 15f)
        invuln = 1f; banner = 1.8f; shake = 0f
        go(St.PLAYING)
        snd.music(true)
    }

    private fun bank(n: Int) {
        val g = max(n, (n * (1f + 0.15f * save.upgrade(3))).roundToInt())
        save.gold += g; runGold += g
    }

    private fun levelClear() {
        timeBonus = timeLeft.toInt() * 5; levelBonus = level * 100
        score += timeBonus + levelBonus; bank(level * 5)
        if (level + 1 > save.bestLevel) save.bestLevel = level + 1
        snd.play("win"); burst(px, py, K(0xFFFFD54F), 40)
        go(St.CLEAR)
    }

    private fun gameOver(why: String) {
        overMsg = why
        newHigh = save.addScore(score)
        if (level > save.bestLevel) save.bestLevel = level
        snd.play("lose")
        go(St.OVER)
    }

    private fun hit() {
        if (invuln > 0f) return
        hearts--; invuln = 1.5f; shake = 0.35f
        snd.play("hit"); burst(px, py, K(0xFFFF5252), 18)
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        if (hearts <= 0) gameOver("Out of lives!")
    }

    private fun burst(x: Float, y: Float, color: Int, n: Int) {
        repeat(n) {
            val a = rnd.nextFloat() * 6.283f; val s = 60f + rnd.nextFloat() * 200f
            parts.add(Particle(x, y, cos(a) * s, sin(a) * s, 0.5f + rnd.nextFloat() * 0.4f, color, 3f + rnd.nextFloat() * 5f))
        }
    }

    private fun pop(x: Float, y: Float, s: String, c: Int) { pops.add(Pop(x, y - 30f, s, c, 1.1f)) }

    // ------------------------------------------------------------ update
    private fun collides(x: Float, y: Float): Boolean {
        val x0 = floor((x - PR) / T).toInt(); val x1 = floor((x + PR) / T).toInt()
        val y0 = floor((y - PR) / T).toInt(); val y1 = floor((y + PR) / T).toInt()
        for (ty in y0..y1) for (tx in x0..x1) if (maze.solid(tx, ty)) {
            val cx = x.coerceIn(tx * T, (tx + 1) * T); val cy = y.coerceIn(ty * T, (ty + 1) * T)
            val dx = x - cx; val dy = y - cy
            if (dx * dx + dy * dy < PR * PR) return true
        }
        return false
    }

    private fun trapState(t: Trap): Int {
        val ph = (time + t.phase) % 2.4f
        return if (ph < 0.8f) 2 else if (ph >= 2.0f) 1 else 0
    }

    private fun update(dt: Float) {
        time += dt
        if (msgT > 0) msgT -= dt
        for (q in parts) { q.x += q.vx * dt; q.y += q.vy * dt; q.vx *= 0.96f; q.vy *= 0.96f; q.life -= dt }
        parts.removeAll { it.life <= 0f }
        for (q in pops) { q.y -= 40f * dt; q.life -= dt }
        pops.removeAll { it.life <= 0f }
        if (st != St.PLAYING) return

        timeLeft -= dt; banner -= dt
        invuln = max(0f, invuln - dt); shake = max(0f, shake - dt)
        if (timeLeft <= 0f) { timeLeft = 0f; gameOver("Time's up!"); return }

        // movement from floating joystick
        var vx = 0f; var vy = 0f
        if (joyId != -1) {
            val dx = jx - jox; val dy = jy - joy; val len = hypot(dx, dy)
            val rad = 56f * u; val dead = 6f * u
            if (len > dead) { val m = min(1f, (len - dead) / (rad - dead)); vx = dx / len * m; vy = dy / len * m }
        }
        moving = vx != 0f || vy != 0f
        if (moving) {
            faceX = vx; faceY = vy
            val spd = BASE_SPEED * (1f + 0.08f * save.upgrade(0))
            var mx = vx * spd * dt; var my = vy * spd * dt
            val steps = max(1, ceil(max(abs(mx), abs(my)) / 8f).toInt())
            mx /= steps; my /= steps
            repeat(steps) { if (!collides(px + mx, py)) px += mx; if (!collides(px, py + my)) py += my }
        }
        val ptx = floor(px / T).toInt(); val pty = floor(py / T).toInt()
        if (maze.secret[pty][ptx]) {
            maze.reveal(ptx, pty); score += 25; snd.play("secret")
            pop((ptx + .5f) * T, (pty + .5f) * T, "SECRET! +25", K(0xFFFFD54F)); burst((ptx + .5f) * T, (pty + .5f) * T, K(0xFFFFE082), 20)
        }

        // items
        val magnet = if (save.upgrade(2) > 0) (1.0f + 0.5f * save.upgrade(2)) * T else 0f
        for (it in items) if (it.alive) {
            var d = hypot(it.x - px, it.y - py)
            if (magnet > 0f && it.type != 2 && d < magnet && d > 1f) {
                it.x += (px - it.x) / d * 260f * dt; it.y += (py - it.y) / d * 260f * dt
                d = hypot(it.x - px, it.y - py)
            }
            if (d < (if (it.type == 2) 46f else 36f)) { it.alive = false; collect(it) }
        }

        // traps
        if (invuln <= 0f) for (t in traps) if (t.tx == ptx && t.ty == pty && trapState(t) == 2) { hit(); break }

        // enemies
        for (e in enemies) {
            val gx = (e.tx + .5f) * T; val gy = (e.ty + .5f) * T
            val dx = gx - e.x; val dy = gy - e.y; val d = hypot(dx, dy); val step = e.spd * dt
            if (d <= step) { e.x = gx; e.y = gy; chooseDir(e) } else { e.x += dx / d * step; e.y += dy / d * step }
            if (invuln <= 0f && hypot(e.x - px, e.y - py) < PR + 22f) hit()
        }

        // exit
        if (st == St.PLAYING && hypot((exitTx + .5f) * T - px, (exitTy + .5f) * T - py) < 38f) levelClear()
    }

    private fun chooseDir(e: Enemy) {
        val dirs = listOf(1 to 0, -1 to 0, 0 to 1, 0 to -1)
        val all = dirs.filter { !maze.blocked(e.tx + it.first, e.ty + it.second) }
        val fwd = all.filter { !(e.tx + it.first == e.ptx && e.ty + it.second == e.pty) }
        val pick = (if (fwd.isNotEmpty()) fwd else all).let { if (it.isEmpty()) return else it[rnd.nextInt(it.size)] }
        e.ptx = e.tx; e.pty = e.ty; e.tx += pick.first; e.ty += pick.second
    }

    private fun collect(it: Item) {
        when (it.type) {
            0 -> { score += 10; runCoins++; bank(1); snd.play("coin"); burst(it.x, it.y, K(0xFFFFD54F), 6); pop(it.x, it.y, "+10", K(0xFFFFEB3B)) }
            1 -> { score += it.value; runGems++; bank(5); snd.play("gem"); burst(it.x, it.y, gemColor(it.value), 12); pop(it.x, it.y, "+${it.value}", gemColor(it.value)) }
            2 -> { score += 300; runChests++; bank(25); snd.play("chest"); burst(it.x, it.y, K(0xFFFFD54F), 36); pop(it.x, it.y, "TREASURE! +300", K(0xFFFFD54F)) }
            3 -> { timeLeft += 8f; snd.play("clock"); burst(it.x, it.y, K(0xFF80DEEA), 10); pop(it.x, it.y, "+8 sec", K(0xFF80DEEA)) }
        }
    }

    private fun gemColor(v: Int) = when (v) { 50 -> K(0xFF29B6F6); 100 -> K(0xFF66BB6A); else -> K(0xFFEC407A) }

    // ------------------------------------------------------------ input
    override fun onTouchEvent(e: MotionEvent): Boolean {
        val i = e.actionIndex
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> touchDown(e.getPointerId(i), e.getX(i), e.getY(i))
            MotionEvent.ACTION_MOVE -> for (k in 0 until e.pointerCount) if (e.getPointerId(k) == joyId) { jx = e.getX(k); jy = e.getY(k) }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> touchUp(e.getPointerId(i), e.getX(i), e.getY(i), e.actionMasked == MotionEvent.ACTION_CANCEL)
        }
        return true
    }

    private fun touchDown(id: Int, x: Float, y: Float) {
        val b = buttons.firstOrNull { it.r.contains(x, y) }
        if (b != null) { pressed = b; return }
        if (st == St.PLAYING && joyId == -1) { joyId = id; jox = x; joy = y; jx = x; jy = y }
    }

    private fun touchUp(id: Int, x: Float, y: Float, cancel: Boolean) {
        if (id == joyId) { joyId = -1; return }
        val b = pressed
        pressed = null
        if (b != null && !cancel && b.r.contains(x, y)) {
            if (!b.hidden || st == St.PLAYING) snd.play("click")
            b.act()
        }
    }

    // ------------------------------------------------------------ drawing helpers
    private fun fill(c: Int, a: Float = 1f) { p.style = Paint.Style.FILL; p.shader = null; p.color = c; if (a < 1f) p.alpha = (p.alpha * a).toInt() }
    private fun stroke(c: Int, w: Float, a: Float = 1f) { p.style = Paint.Style.STROKE; p.shader = null; p.strokeWidth = w; p.color = c; if (a < 1f) p.alpha = (p.alpha * a).toInt() }
    private fun txt(s: String, x: Float, y: Float, size: Float, color: Int, align: Paint.Align = Paint.Align.CENTER, shadow: Boolean = true) {
        tp.textSize = size; tp.textAlign = align
        if (shadow) { tp.color = K(0xAA000000); cv.drawText(s, x + size * 0.05f, y + size * 0.07f, tp) }
        tp.color = color; cv.drawText(s, x, y, tp)
    }
    private fun oval(l: Float, t: Float, r: Float, b: Float) { rf.set(l, t, r, b); cv.drawOval(rf, p) }
    private fun rrect(l: Float, t: Float, r: Float, b: Float, rad: Float) { rf.set(l, t, r, b); cv.drawRoundRect(rf, rad, rad, p) }

    private fun heart(x: Float, y: Float, s: Float, color: Int) {
        path.reset()
        path.moveTo(x, y + s * 0.9f)
        path.cubicTo(x - s * 1.4f, y - s * 0.1f, x - s * 0.6f, y - s * 1.1f, x, y - s * 0.35f)
        path.cubicTo(x + s * 0.6f, y - s * 1.1f, x + s * 1.4f, y - s * 0.1f, x, y + s * 0.9f)
        path.close(); fill(color); cv.drawPath(path, p)
    }

    private fun drawCoin(x: Float, y: Float, r: Float, t: Float) {
        val w = abs(cos(t)) * r + r * 0.15f
        fill(K(0xFFFFC107)); oval(x - w, y - r, x + w, y + r)
        stroke(K(0xFFB26A00), r * 0.18f); oval(x - w, y - r, x + w, y + r)
        fill(K(0xFFFFE082)); oval(x - w * 0.5f, y - r * 0.6f, x + w * 0.5f, y + r * 0.6f)
    }

    private fun drawGem(x: Float, y: Float, r: Float, color: Int, t: Float) {
        path.reset()
        path.moveTo(x, y - r); path.lineTo(x + r * 0.9f, y - r * 0.1f); path.lineTo(x, y + r); path.lineTo(x - r * 0.9f, y - r * 0.1f); path.close()
        fill(color); cv.drawPath(path, p)
        stroke(shade(color, 0.55f), r * 0.14f); cv.drawPath(path, p)
        stroke(K(0xFFFFFFFF), r * 0.08f, 0.6f)
        cv.drawLine(x - r * 0.9f, y - r * 0.1f, x + r * 0.9f, y - r * 0.1f, p)
        cv.drawLine(x - r * 0.35f, y - r * 0.1f, x, y - r, p); cv.drawLine(x + r * 0.35f, y - r * 0.1f, x, y - r, p)
        val s = r * 0.3f * (0.6f + 0.4f * sin(t * 3f))
        stroke(K(0xFFFFFFFF), r * 0.1f)
        cv.drawLine(x + r * 0.4f - s, y - r * 0.5f, x + r * 0.4f + s, y - r * 0.5f, p)
        cv.drawLine(x + r * 0.4f, y - r * 0.5f - s, x + r * 0.4f, y - r * 0.5f + s, p)
    }

    private fun drawClock(x: Float, y: Float, r: Float) {
        fill(K(0xFFFFFFFF)); cv.drawCircle(x, y, r, p)
        stroke(K(0xFF00ACC1), r * 0.2f); cv.drawCircle(x, y, r, p)
        stroke(K(0xFF00838F), r * 0.12f)
        cv.drawLine(x, y, x, y - r * 0.6f, p); cv.drawLine(x, y, x + r * 0.4f, y + r * 0.15f, p)
    }

    private fun drawChest(x: Float, y: Float, a: Float) {
        fill(K(0xFF8D5524), a); rrect(x - 24f, y - 8f, x + 24f, y + 18f, 4f)
        fill(K(0xFF6D3F1A), a); rrect(x - 24f, y - 22f, x + 24f, y - 4f, 8f)
        fill(K(0xFFFFC107), a); cv.drawRect(x - 5f, y - 22f, x + 5f, y + 18f, p)
        cv.drawRect(x - 24f, y - 6f, x + 24f, y - 2f, p)
        fill(K(0xFFFFE082), a); cv.drawCircle(x, y - 1f, 5f, p)
        stroke(K(0xFF3E2410), 3f, a); rrect(x - 24f, y - 22f, x + 24f, y + 18f, 6f)
    }

    private fun drawSparkle(x: Float, y: Float, r: Float, a: Float) {
        stroke(K(0xFFFFF59D), 3f, a)
        cv.drawLine(x - r, y, x + r, y, p); cv.drawLine(x, y - r, x, y + r, p)
        cv.drawLine(x - r * 0.5f, y - r * 0.5f, x + r * 0.5f, y + r * 0.5f, p)
        cv.drawLine(x - r * 0.5f, y + r * 0.5f, x + r * 0.5f, y - r * 0.5f, p)
    }

    private fun drawSlime(x: Float, y: Float, kind: Int, t: Float) {
        val col = arrayOf(K(0xFF66BB6A), K(0xFFAB47BC), K(0xFFEF5350))[kind]
        val sq = sin(t * 6f) * 3f
        fill(K(0x55000000)); oval(x - 24f, y + 12f, x + 24f, y + 24f)
        fill(col); oval(x - 26f - sq, y - 20f + sq, x + 26f + sq, y + 20f)
        fill(K(0x55FFFFFF)); oval(x - 14f, y - 14f + sq, x - 2f, y - 6f + sq)
        fill(K(0xFFFFFFFF)); cv.drawCircle(x - 9f, y - 2f, 7f, p); cv.drawCircle(x + 9f, y - 2f, 7f, p)
        fill(K(0xFF212121)); cv.drawCircle(x - 8f, y - 1f, 3.5f, p); cv.drawCircle(x + 8f, y - 1f, 3.5f, p)
        stroke(K(0xFF212121), 3f); cv.drawLine(x - 16f, y - 12f, x - 4f, y - 8f, p); cv.drawLine(x + 16f, y - 12f, x + 4f, y - 8f, p)
    }

    private fun drawHero(x: Float, y: Float, s: Float, sk: Skin, fdx: Float, fdy: Float, bob: Float) {
        cv.save(); cv.translate(x, y); cv.scale(s, s)
        val l = hypot(fdx, fdy).let { if (it < 0.01f) 1f else it }
        val ex = fdx / l; val ey = fdy / l
        fill(K(0x55000000)); oval(-22f, 16f, 22f, 30f)
        fill(sk.body); oval(-26f, -26f + bob, 26f, 26f - bob)
        stroke(shade(sk.body, 0.6f), 3f); oval(-26f, -26f + bob, 26f, 26f - bob)
        fill(K(0x44FFFFFF)); oval(-18f, -10f, -6f, 2f)
        fill(K(0xFFFFFFFF)); cv.drawCircle(-9f + ex * 2f, 0f + ey * 2f, 7.5f, p); cv.drawCircle(9f + ex * 2f, 0f + ey * 2f, 7.5f, p)
        fill(K(0xFF212121)); cv.drawCircle(-9f + ex * 4f, 0f + ey * 4f, 3.8f, p); cv.drawCircle(9f + ex * 4f, 0f + ey * 4f, 3.8f, p)
        fill(shade(sk.body, 0.6f)); oval(-5f, 10f, 5f, 15f)
        fill(sk.hat); oval(-27f, -22f, 27f, -10f)
        rrect(-15f, -40f, 15f, -16f, 8f)
        fill(K(0xFFFFD54F)); cv.drawRect(-15f, -26f, 15f, -20f, p)
        stroke(shade(sk.hat, 0.55f), 2.5f); oval(-27f, -22f, 27f, -10f)
        cv.restore()
    }

    private fun drawPortal(x: Float, y: Float) {
        val a = time * 2f
        fill(K(0x4400E5FF)); cv.drawCircle(x, y, 40f + 3f * sin(time * 4f), p)
        fill(K(0xFF7C4DFF)); cv.drawCircle(x, y, 32f, p)
        fill(K(0xFF00E5FF)); cv.drawCircle(x, y, 23f, p)
        fill(K(0xFFFFFFFF)); cv.drawCircle(x, y, 13f + 2f * sin(time * 6f), p)
        for (i in 0 until 6) {
            val an = a + i * 1.047f
            fill(K(0xFFFFFFFF)); cv.drawCircle(x + cos(an) * 38f, y + sin(an) * 38f, 3.5f, p)
        }
    }

    private fun drawSpikes(x: Float, y: Float, s: Int) {
        fill(K(0xFF2B2B33)); rrect(x - 30f, y - 30f, x + 30f, y + 30f, 8f)
        if (s == 2) { fill(K(0x44FF1744)); cv.drawCircle(x, y, 40f, p) }
        val h = when (s) { 2 -> 24f; 1 -> 10f; else -> 3f }
        for (ix in 0..1) for (iy in 0..1) {
            val cx = x + (ix * 2 - 1) * 14f; val cy = y + (iy * 2 - 1) * 14f
            path.reset(); path.moveTo(cx - 8f, cy + 8f); path.lineTo(cx, cy + 8f - h - 4f); path.lineTo(cx + 8f, cy + 8f); path.close()
            fill(if (s == 2) K(0xFFE0E0E0) else K(0xFF78909C)); cv.drawPath(path, p)
            if (s == 2) { stroke(K(0xFFD32F2F), 2.5f); cv.drawPath(path, p) }
        }
    }

    // ------------------------------------------------------------ screens
    override fun onDraw(canvas: Canvas) {
        cv = canvas
        val now = System.nanoTime()
        val dt = if (lastNs == 0L) 0.016f else min(0.033f, (now - lastNs) / 1e9f)
        lastNs = now
        update(dt)
        when (st) {
            St.MENU -> drawMenu()
            St.SHOP -> drawShop()
            St.SCORES -> drawScores()
            else -> {
                drawWorld(); drawHud()
                if (st != St.PLAYING) {
                    fill(K(0x99000000)); cv.drawRect(0f, 0f, W, H, p)
                    when (st) { St.PAUSED -> drawPause(); St.CLEAR -> drawClear(); else -> drawOver() }
                }
            }
        }
        for (b in buttons) drawBtn(b)
        postInvalidateOnAnimation()
    }

    private fun drawBtn(b: Btn) {
        if (b.hidden) return
        val r = b.r; val off = if (b === pressed) 4f * u else 0f
        fill(shade(b.color, 0.6f)); rf.set(r.left, r.top + 5f * u, r.right, r.bottom + 5f * u); cv.drawRoundRect(rf, 16f * u, 16f * u, p)
        fill(b.color); rf.set(r.left, r.top + off, r.right, r.bottom + off); cv.drawRoundRect(rf, 16f * u, 16f * u, p)
        fill(K(0xFFFFFFFF), 0.2f); rf.set(r.left + 8f * u, r.top + off + 5f * u, r.right - 8f * u, r.top + off + r.height() * 0.42f); cv.drawRoundRect(rf, 10f * u, 10f * u, p)
        val size = r.height() * 0.42f
        txt(b.label, r.centerX(), r.centerY() + off + size * 0.35f, size, K(0xFFFFFFFF))
    }

    private fun drawBackdrop() {
        p.style = Paint.Style.FILL; p.shader = bgShader; cv.drawRect(0f, 0f, W, H, p); p.shader = null
        for (i in 0 until 18) {
            val x = W * (((i * 0.3719f) + 0.07f) % 1f)
            val y = ((time * (28f + (i % 4) * 14f) + i * 131f * u) % (H + 120f)) - 60f
            val r = (9f + (i % 3) * 4f) * u
            if (i % 3 == 0) drawGem(x, y, r * 1.2f, gemColor(listOf(50, 100, 200)[(i / 3) % 3]), time + i)
            else drawCoin(x, y, r, time * 3f + i)
        }
    }

    private fun drawMenu() {
        drawBackdrop()
        txt("TREASURE", W / 2, oy + 150f * u, 54f * u, K(0xFFFFFFFF))
        txt("HUNTER", W / 2, oy + 212f * u, 64f * u, K(0xFFFFC107))
        drawHero(W / 2, oy + 300f * u, 1.6f * u, SKINS[save.skin], sin(time * 1.5f), 1f, sin(time * 5f) * 1.5f)
        txt("GOLD ${save.gold}", W / 2, oy + 722f * u, 22f * u, K(0xFFFFE082))
        txt("Best level: ${save.bestLevel}", W / 2, oy + 752f * u, 16f * u, K(0xFFD1C4E9))
    }

    private fun drawShop() {
        drawBackdrop()
        fill(K(0x77000000)); cv.drawRect(0f, 0f, W, H, p)
        txt("SHOP", W / 2, oy + 50f * u, 38f * u, K(0xFFFFFFFF))
        drawCoin(ox + 120f * u, oy + 84f * u, 11f * u, 0f)
        txt("${save.gold}", ox + 140f * u, oy + 92f * u, 24f * u, K(0xFFFFE082), Paint.Align.LEFT)
        txt("SKINS", ox + 16f * u, oy + 126f * u, 16f * u, K(0xFFB39DDB), Paint.Align.LEFT)
        for (i in SKINS.indices) {
            val r = skinRect(i); val sk = SKINS[i]; val own = save.owned and (1 shl i) != 0; val sel = save.skin == i
            fill(K(0xFF3A2A6E)); cv.drawRoundRect(r, 14f * u, 14f * u, p)
            if (sel) { stroke(K(0xFFFFC107), 3f * u); cv.drawRoundRect(r, 14f * u, 14f * u, p) }
            drawHero(r.centerX(), r.top + 46f * u, 1.05f * u, sk, 0f, 1f, 0f)
            txt(sk.name, r.centerX(), r.top + 88f * u, 13f * u, K(0xFFFFFFFF), shadow = false)
            val label = if (sel) "SELECTED" else if (own) "TAP TO USE" else "${sk.price} G"
            txt(label, r.centerX(), r.top + 108f * u, 13f * u, if (own) K(0xFF81C784) else K(0xFFFFE082), shadow = false)
        }
        txt("UPGRADES", ox + 16f * u, oy + 424f * u, 16f * u, K(0xFFB39DDB), Paint.Align.LEFT)
        for (i in 0..3) {
            val r = upRect(i); val lvl = save.upgrade(i)
            fill(K(0xFF3A2A6E)); cv.drawRoundRect(r, 14f * u, 14f * u, p)
            txt(UP_NAMES[i], r.left + 14f * u, r.top + 26f * u, 17f * u, K(0xFFFFFFFF), Paint.Align.LEFT, false)
            txt(UP_DESC[i], r.left + 14f * u, r.top + 46f * u, 12f * u, K(0xFFD1C4E9), Paint.Align.LEFT, false)
            for (k in 0 until UP_MAX[i]) {
                fill(if (k < lvl) K(0xFFFFC107) else K(0xFF5E4B9A)); cv.drawCircle(r.left + 170f * u + k * 13f * u, r.top + 30f * u, 4.5f * u, p)
            }
            val cost = UP_BASE[i] * (lvl + 1)
            if (lvl >= UP_MAX[i]) txt("MAX", r.right - 14f * u, r.top + 36f * u, 17f * u, K(0xFF81C784), Paint.Align.RIGHT, false)
            else txt("$cost G", r.right - 14f * u, r.top + 36f * u, 17f * u, if (save.gold >= cost) K(0xFFFFE082) else K(0xFFEF9A9A), Paint.Align.RIGHT, false)
        }
        if (msgT > 0f) txt(msg, W / 2, oy + 704f * u, 16f * u, K(0xFFFFFFFF))
    }

    private fun drawScores() {
        drawBackdrop()
        fill(K(0x77000000)); cv.drawRect(0f, 0f, W, H, p)
        txt("HIGH SCORES", W / 2, oy + 90f * u, 38f * u, K(0xFFFFC107))
        val sc = save.scores()
        for (i in 0 until 5) {
            val r = rect(30f, 130f + i * 80f, 300f, 66f)
            fill(K(0xFF3A2A6E)); cv.drawRoundRect(r, 14f * u, 14f * u, p)
            txt("#${i + 1}", r.left + 20f * u, r.centerY() + 9f * u, 26f * u, if (i == 0) K(0xFFFFC107) else K(0xFFB39DDB), Paint.Align.LEFT)
            txt(if (i < sc.size) "${sc[i]}" else "---", r.right - 20f * u, r.centerY() + 9f * u, 26f * u, K(0xFFFFFFFF), Paint.Align.RIGHT)
        }
        txt("Best level reached: ${save.bestLevel}", W / 2, oy + 640f * u, 18f * u, K(0xFFD1C4E9))
    }

    private fun panel(x: Float, y: Float, w: Float, h: Float) {
        val r = rect(x, y, w, h)
        fill(K(0xF0241A4D)); cv.drawRoundRect(r, 22f * u, 22f * u, p)
        stroke(K(0xFFFFC107), 3f * u); cv.drawRoundRect(r, 22f * u, 22f * u, p)
    }

    private fun drawPause() {
        panel(30f, 190f, 300f, 370f)
        txt("PAUSED", W / 2, oy + 270f * u, 42f * u, K(0xFFFFFFFF))
        txt("Level $level   Score $score", W / 2, oy + 306f * u, 16f * u, K(0xFFD1C4E9))
    }

    private fun drawClear() {
        panel(30f, 150f, 300f, 440f)
        txt("LEVEL $level", W / 2, oy + 225f * u, 30f * u, K(0xFFFFFFFF))
        txt("COMPLETE!", W / 2, oy + 275f * u, 40f * u, K(0xFF69F0AE))
        txt("Time bonus  +$timeBonus", W / 2, oy + 335f * u, 20f * u, K(0xFFFFE082))
        txt("Level bonus  +$levelBonus", W / 2, oy + 370f * u, 20f * u, K(0xFFFFE082))
        txt("Score  $score", W / 2, oy + 425f * u, 28f * u, K(0xFFFFFFFF))
        txt("Gold earned this run  $runGold", W / 2, oy + 465f * u, 16f * u, K(0xFFD1C4E9))
    }

    private fun drawOver() {
        panel(30f, 130f, 300f, 550f)
        txt("GAME OVER", W / 2, oy + 205f * u, 40f * u, K(0xFFFF5252))
        txt(overMsg, W / 2, oy + 240f * u, 18f * u, K(0xFFD1C4E9))
        txt("Score  $score", W / 2, oy + 300f * u, 30f * u, K(0xFFFFFFFF))
        if (newHigh) txt("NEW HIGH SCORE!", W / 2, oy + 340f * u, 22f * u, K(0xFFFFC107))
        txt("Reached level $level", W / 2, oy + 380f * u, 17f * u, K(0xFFD1C4E9))
        txt("Coins $runCoins   Gems $runGems   Chests $runChests", W / 2, oy + 406f * u, 14f * u, K(0xFFD1C4E9))
        txt("Gold earned  +$runGold", W / 2, oy + 432f * u, 17f * u, K(0xFFFFE082))
    }

    private fun drawWorld() {
        val th = THEMES[((level - 1) / 2) % THEMES.size]
        cv.drawColor(th.bg)
        val S = W / (T * 7f)
        val sx = if (shake > 0f) (rnd.nextFloat() - .5f) * shake * 40f else 0f
        val sy = if (shake > 0f) (rnd.nextFloat() - .5f) * shake * 40f else 0f
        cv.save()
        cv.translate(W / 2 - px * S + sx, H * 0.5f - py * S + sy)
        cv.scale(S, S)
        val hw = W / S / 2 + T; val hh = H / S / 2 + T
        val x0 = max(0, floor((px - hw) / T).toInt()); val x1 = min(maze.w - 1, floor((px + hw) / T).toInt())
        val y0 = max(0, floor((py - hh) / T).toInt()); val y1 = min(maze.h - 1, floor((py + hh) / T).toInt())
        // floors
        for (ty in y0..y1) for (tx in x0..x1) if (!maze.wall[ty][tx]) {
            fill(if ((tx + ty) % 2 == 0) th.floorA else th.floorB); cv.drawRect(tx * T, ty * T, (tx + 1) * T, (ty + 1) * T, p)
            if (maze.revealed[ty][tx]) { fill(K(0xFFFFD54F), 0.18f + 0.1f * sin(time * 3f)); cv.drawRect(tx * T, ty * T, (tx + 1) * T, (ty + 1) * T, p) }
        }
        // traps, exit
        for (t in traps) if (t.tx in x0..x1 && t.ty in y0..y1) drawSpikes((t.tx + .5f) * T, (t.ty + .5f) * T, trapState(t))
        drawPortal((exitTx + .5f) * T, (exitTy + .5f) * T)
        // items
        for (it in items) if (it.alive && abs(it.x - px) < hw && abs(it.y - py) < hh) {
            val d = hypot(it.x - px, it.y - py)
            val bob = sin(time * 4f + it.x) * 3f
            when (it.type) {
                0 -> drawCoin(it.x, it.y + bob, 15f, time * 4f + it.x)
                1 -> drawGem(it.x, it.y + bob, 19f, gemColor(it.value), time + it.x)
                2 -> if (d < 2.4f * T) drawChest(it.x, it.y, 1f) else if (d < 4.5f * T) drawSparkle(it.x, it.y, 10f + 4f * sin(time * 5f), 0.5f + 0.5f * sin(time * 4f))
                3 -> drawClock(it.x, it.y + bob, 16f)
            }
        }
        // player and enemies
        for (e in enemies) drawSlime(e.x, e.y, e.kind, time + e.x)
        if (invuln <= 0f || (time * 14f).toInt() % 2 == 0)
            drawHero(px, py, 1f, SKINS[save.skin], faceX, faceY, if (moving) sin(time * 16f) * 2f else 0f)
        // walls
        for (ty in y0..y1) for (tx in x0..x1) if (maze.wall[ty][tx]) {
            val x = tx * T; val y = ty * T
            fill(th.wallTop); cv.drawRect(x, y, x + T, y + T, p)
            fill(K(0xFFFFFFFF), 0.12f); cv.drawRect(x, y, x + T, y + 7f, p)
            if (ty + 1 < maze.h && !maze.wall[ty + 1][tx]) {
                fill(th.wallFace); cv.drawRect(x, y + T * 0.7f, x + T, y + T, p)
                fill(K(0xFF000000), 0.18f); cv.drawRect(x, y + T * 0.7f, x + T, y + T * 0.74f, p)
                stroke(shade(th.wallFace, 0.7f), 2f); cv.drawLine(x, y + T * 0.85f, x + T, y + T * 0.85f, p)
            }
            if (maze.secret[ty][tx]) {
                stroke(shade(th.wallFace, 0.55f), 3f)
                path.reset(); path.moveTo(x + T * .5f, y + T * .1f); path.lineTo(x + T * .38f, y + T * .38f)
                path.lineTo(x + T * .6f, y + T * .58f); path.lineTo(x + T * .48f, y + T * .88f); cv.drawPath(path, p)
                if (hypot(x + T / 2 - px, y + T / 2 - py) < 2.5f * T) drawSparkle(x + T * .7f, y + T * .3f, 7f, 0.5f + 0.5f * sin(time * 6f))
            }
        }
        // particles / popups
        for (q in parts) { fill(q.color, (q.life * 2f).coerceIn(0f, 1f)); cv.drawCircle(q.x, q.y, q.size * min(1f, q.life * 2f + 0.2f), p) }
        for (q in pops) txt(q.text, q.x, q.y, 22f, withA(q.color, (q.life * 500f).toInt()))
        cv.restore()
        // vignette + exit compass
        p.style = Paint.Style.FILL; p.shader = vigShader; cv.drawRect(0f, 0f, W, H, p); p.shader = null
        if (st == St.PLAYING) {
            val ex = (exitTx + .5f) * T - px; val ey = (exitTy + .5f) * T - py
            if (hypot(ex, ey) > 3.5f * T) {
                val a = atan2(ey, ex); val cx = W / 2 + cos(a) * 62f * u; val cy = H * 0.5f + sin(a) * 62f * u
                path.reset()
                path.moveTo(cx + cos(a) * 12f * u, cy + sin(a) * 12f * u)
                path.lineTo(cx + cos(a + 2.5f) * 10f * u, cy + sin(a + 2.5f) * 10f * u)
                path.lineTo(cx + cos(a - 2.5f) * 10f * u, cy + sin(a - 2.5f) * 10f * u)
                path.close(); fill(K(0xFF00E5FF), 0.8f); cv.drawPath(path, p)
            }
        }
    }

    private fun drawHud() {
        val top = topInset
        fill(K(0x99000000)); cv.drawRect(0f, 0f, W, top + 64f * u, p)
        for (i in 0 until maxHearts) heart(18f * u + i * 24f * u, top + 22f * u, 8f * u, if (i < hearts) K(0xFFFF5252) else K(0xFF4A4A5A))
        txt("LEVEL $level", W / 2 + 10f * u, top + 28f * u, 18f * u, K(0xFFFFFFFF))
        txt("SCORE $score", 12f * u, top + 56f * u, 17f * u, K(0xFFFFE082), Paint.Align.LEFT)
        drawCoin(W / 2 - 10f * u, top + 50f * u, 8f * u, 0f)
        txt("x$runCoins", W / 2 + 4f * u, top + 56f * u, 16f * u, K(0xFFFFFFFF), Paint.Align.LEFT)
        val tl = timeLeft.toInt()
        val low = timeLeft < 10f && (time * 4f).toInt() % 2 == 0
        txt("%d:%02d".format(tl / 60, tl % 60), W - 12f * u, top + 56f * u, 20f * u, if (timeLeft < 10f) (if (low) K(0xFFFF1744) else K(0xFFFFFFFF)) else K(0xFF80DEEA), Paint.Align.RIGHT)
        // pause icon
        val b = buttons.firstOrNull { it.hidden }
        if (st == St.PLAYING && b != null) {
            fill(K(0x66FFFFFF)); cv.drawCircle(b.r.centerX(), b.r.centerY(), 18f * u, p)
            fill(K(0xFFFFFFFF)); cv.drawRect(b.r.centerX() - 7f * u, b.r.centerY() - 8f * u, b.r.centerX() - 2f * u, b.r.centerY() + 8f * u, p)
            cv.drawRect(b.r.centerX() + 2f * u, b.r.centerY() - 8f * u, b.r.centerX() + 7f * u, b.r.centerY() + 8f * u, p)
        }
        if (st == St.PLAYING && banner > 0f) {
            val a = (min(1f, banner) * 255).toInt()
            txt("LEVEL $level", W / 2, H * 0.3f, 46f * u, withA(K(0xFFFFFFFF), a))
            if (level == 1) txt("Touch & drag to move. Find the portal!", W / 2, H * 0.3f + 34f * u, 15f * u, withA(K(0xFFFFE082), a))
        }
        if (joyId != -1 && st == St.PLAYING) {
            val rad = 56f * u
            fill(K(0xFFFFFFFF), 0.15f); cv.drawCircle(jox, joy, rad, p)
            stroke(K(0xFFFFFFFF), 2f * u, 0.4f); cv.drawCircle(jox, joy, rad, p)
            val dx = jx - jox; val dy = jy - joy; val l = max(1f, hypot(dx, dy)); val m = min(l, rad)
            fill(K(0xFFFFFFFF), 0.55f); cv.drawCircle(jox + dx / l * m, joy + dy / l * m, 24f * u, p)
        }
    }
}
